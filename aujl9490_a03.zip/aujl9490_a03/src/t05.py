"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-01-28"
-------------------------------------------------------
"""
from functions import is_palindrome_stack

string = str(input("Enter a string:"))

palindrome = is_palindrome_stack(string)

print(palindrome)
