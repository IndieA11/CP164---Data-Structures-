"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-01-28""
-------------------------------------------------------
"""
# Imports
from functions import reroute

opstring = str(input("Enter Opstring:"))

values_in = [1, 2, 3, 4, 5]

values_out = reroute(opstring, values_in)

print(values_out)
