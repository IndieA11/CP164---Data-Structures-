"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-01-28"
-------------------------------------------------------
"""
from Stack_array import Stack
from functions import stack_combine
from utilities import array_to_stack

source1 = Stack()
source2 = Stack()

array_to_stack(source1, [1, 2, 3, 4])

array_to_stack(source2, [2, 4, 6, 8, 10])

target = stack_combine(source1, source2)

while not (target.is_empty()):
    value = target.pop()
    print(value)
