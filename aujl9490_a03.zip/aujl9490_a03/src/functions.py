
"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-01-28"
-------------------------------------------------------
"""
# Imports

# Constants

from Stack_array import Stack

# Constants


def stack_combine(source1, source2):
    """
    -------------------------------------------------------
    Combines two source stacks into a target stack.
    When finished, the contents of source1 and source2 are interlaced
    into target and source1 and source2 are empty.
    Use: target = stack_combine(source1, source2)
    -------------------------------------------------------
    Parameters:
        source1 - a stack (Stack)
        source2 - another stack (Stack)
    Returns:
        target - the contents of the source1 and source2
            are interlaced into target (Stack)
    -------------------------------------------------------
    """
    target = Stack()

    while (not source1.is_empty()) and (not source2.is_empty()):
        target.push(source1.pop())
        target.push(source2.pop())

    while not source1.is_empty():
        target.push(source1.pop())

    while not source2.is_empty:
        target.push(source2.pop())

    return target


def stack_reverse(source):
    """
    -------------------------------------------------------
    Reverses the contents of a stack.
    Use: stack_reverse(source)
    -------------------------------------------------------
    Parameters:
        source - a Stack (Stack)
    Returns:
        None
    -------------------------------------------------------
    """
    list = []
    source = Stack()

    while not source.is_empty():
        list.append(source.pop())

    for i in range(len(list)):
        source.push(list[i])

    return


def is_palindrome_stack(string):
    """
    -------------------------------------------------------
    Determines if string is a palindrome. Ignores case, digits, spaces, and
    punctuation in string.
    Use: palindrome = is_palindrome_stack(string)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
    Returns:
        palindrome - True if string is a palindrome, False otherwise (bool)
    -------------------------------------------------------
    """
    lower = string.lower()  # temp
    string = ""

    for i in lower:
        if i.isalpha():
            string += i

    s = Stack()
    palindrome = True

    length = len(string)
    i = 0
    count = length // 2  # half

    while i < count:
        s.push(string[i])
        i += 1

    if length % 2 != 0:
        i += 1

    while (palindrome == True) and (i < length) and not s.is_empty():
        inc = s.pop()

        if string[i] != inc:
            palindrome = False

        else:
            i += 1

    if not (i == length and s.is_empty()):
        palindrome = False

    return palindrome


def reroute(opstring, values_in):
    """
    -------------------------------------------------------
    Reroutes values in a list according to a operating string and
    returns a new list of values. values_in is unchanged.
    In opstring, 'S' means push onto stack,
    'X' means pop from stack into values_out.
    Use: values_out = reroute(opstring, values_in)
    -------------------------------------------------------
    Parameters:
        opstring - String containing only 'S' and 'X's (str)
        values_in - A valid list (list of ?)
    Returns:
        values_out - if opstring is valid then values_out contains a
            reordered version of values_in, otherwise returns
            None (list of ?)
    -------------------------------------------------------
    """
    s = Stack()
    values_out = []
    count = 0  # index
    indexvalue = 0  # valuesindex
    valid = True  # cont

    while count < len(opstring) and (valid == True) and indexvalue <= len(values_in):
        if (opstring[count] == "S") and (indexvalue < len(values_in)):
            s.push(values_in[indexvalue])
            indexvalues = indexvalue + 1

        elif (opstring[count] == "X"):
            if (s.is_empty()):
                valid = False
                values_out = None

            else:
                values_out.append(s.pop())

        count = count + 1

    if not (s.is_empty()):
        values_out = None
    elif count < (len(opstring) - 1):
        values_out = None

    elif indexvalue < (len(values_in) - 1):
        values_out = None

    return values_out
