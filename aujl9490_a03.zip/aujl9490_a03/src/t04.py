"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-01-28"
-------------------------------------------------------
"""
from Stack_array import Stack
from utilities import array_to_stack

source1 = Stack()

array_to_stack(source1, [4, 8, 12, 16])


print(source1._values)

while not source1.is_empty():
    value = source1.pop()
    print(value)
