"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-01-28"
-------------------------------------------------------
"""
# Imports

# Constants
from Stack_array import Stack
from functions import stack_reverse
from utilities import array_to_stack

source1 = Stack()

array_to_stack(source1, [3, 6, 9, 12])

stack_reverse(source1)

while not source1.is_empty():
    value = source1.pop()
    print(value)
