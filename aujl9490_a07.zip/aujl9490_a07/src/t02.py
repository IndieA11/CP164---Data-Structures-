"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-03-10"
-------------------------------------------------------
"""
# Imports

# Constants

from Sorted_List_array import Sorted_List


# Test the clean method

# Set up a sorted list
lst = Sorted_List()

# Use the insert method to
#  add values to the list
lst.insert(100)

lst.insert(200)

lst.insert(200)

lst.clean()

# Print the values to make sure it works
print()
print("Printing")
for value in lst:
    print(value)


# Test the contains method

# Print to make sure it works
print()
print("Printing")
print(100 in lst)


# Test the count method

# Insert a duplicate value
lst.insert(100)

# Test the count method
print()
print("Printing")
print(lst.count(100))


# Test the find method

# Find 100
print()
print("Printing")
print(lst.find(100))


# Test the __getitem__ method

# Print the 3rd item in the list
print()
print("Printing")
print(lst[2])


# Test the index method

# Print the results
print()
print("Printing")
print(lst.index(100))


# Test the intersection method

# Create an empty list
lst2 = Sorted_List()

# Add values
lst2.insert(100)

lst2.insert(1000)

# Create another empty list
lst3 = Sorted_List()

# Use the intersection method
lst3.intersection(lst, lst2)
