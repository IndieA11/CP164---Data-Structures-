"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-03-10"
-------------------------------------------------------
"""
# Imports
from List_linked import List
l = List()
l.append(44)

t1, t2 = l.split()


# l.clean()
for i in t1:
    print(i)
print()
for j in t2:
    print(j)
