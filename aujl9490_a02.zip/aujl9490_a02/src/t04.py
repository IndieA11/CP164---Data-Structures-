"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-01-21"
-------------------------------------------------------
"""
# Imports
from Food_utilities import food_table
from Food_utilities import read_foods
from Food import Food


file_variable = open("foods.txt", "r", encoding="utf-8")

foods = read_foods(file_variable)

for f in foods:
    print(f)

t = food_table(foods)

print(t)

# Constants
