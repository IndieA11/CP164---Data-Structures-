"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-01-21"
-------------------------------------------------------
"""
# Imports
from Food_utilities import calories_by_origin
from Food_utilities import read_foods
from Food import Food
# Constants

file_variable = open("foods.txt", "r", encoding="utf-8")

origin = int(input("Enter an Origin: "))

foods = read_foods(file_variable)

a = calories_by_origin(foods, origin)

print(f"The average number of calories is: {a}")
