"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-01-21"
-------------------------------------------------------
"""
from Food_utilities import read_foods
from Food_utilities import food_table
from Food_utilities import food_search

file_variable = open("foods.txt", "rt", encoding="utf-8")

foods = read_foods(file_variable)

origin = 1
max_cals = 300
is_veg = False

result = food_search(foods, origin, max_cals, is_veg)

food_table(result)
