"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-03-02"
-------------------------------------------------------
"""
# Imports
from Queue_linked import Queue
# Constants

source1 = Queue()
source2 = Queue()
target = Queue()
source = Queue()

values = [1, 2, 3, 4, 5]
num = [2, 4, 6, 8, 10]

for i in values:
    source1.insert(i)

for i in num:
    source2.insert(i)

target.combine(source1, source2)

print("combined")

for item in target:
    print(item)

value = target.peek()
print(f"peeked value: {value}")

value = target.remove()
print(f"remove value: {value}")

b = target.is_empty()
print(f" empty: {b}")

b = source.is_identical(target)
print(f" identical: {b}")
