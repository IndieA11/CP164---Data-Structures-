"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-02-02"
-------------------------------------------------------
"""

from Queue_circular import Queue

testqueue = Queue(4)

print(len(testqueue))

print(testqueue.is_empty)

testqueue.insert(20)

print(len(testqueue))

value = testqueue.peek()

print(value)

valueremoved = testqueue.remove()

print(valueremoved)

testqueue.insert(1)
testqueue.insert(2)
testqueue.insert(3)

print(testqueue.is_full())
