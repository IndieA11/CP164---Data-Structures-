"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-02-02"
-------------------------------------------------------
"""
# Imports

# Constants
# Imports
from Queue_circular import Queue
from functions import queue_split_alt
# Constants

source = Queue()

source.insert(2)
source.insert(4)
source.insert(6)

target1, target2 = source.split_alt()

print("target 1")
while len(target1) > 0:
    print(target1.remove())

print("target 2")
while len(target2) > 0:
    print(target2.remove())
