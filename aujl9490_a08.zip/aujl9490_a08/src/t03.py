"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Indu Aujla
ID:      210349490
Email:   aujl9490@mylaurier.ca
__updated__ = "2022-03-15"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from Letter import Letter
from functions import letter_table


x = BST()
a = Letter("A")
b = Letter("B")
c = Letter("C")
d = Letter("D")
a == b
b == c
b == a
c == d
x.insert(a)
x.insert(b)
x.insert(c)
x.insert(d)

letter_table(x)
